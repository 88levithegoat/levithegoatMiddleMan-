SETUP — EMAIL NOTIFICATIONS

This version uses FormSubmit to email new transaction submissions to:
yungstunna1of1@gmail.com

IMPORTANT:
1. Upload index.html to your GitHub Pages site.
2. Submit a test transaction.
3. FormSubmit may send a confirmation/activation email to the destination address. Complete that confirmation if requested.
4. Replace the _next value (currently https://example.com/thanks) with your actual GitHub Pages URL if you want users redirected to a real thank-you page.
5. The 4-digit code is generated in the browser and included in the email.
6. The Discord invite is https://discord.gg/FpGgD4htw.

SECURITY:
Do not collect PSN passwords, 2FA codes, recovery codes, payment-card numbers, or other account-security credentials in the form.
The 4-digit code is a transaction reference, not an authentication secret.

For a production system, use a real backend/database and server-side code generation rather than relying on browser-side codes.
